package com.tl.listener;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.ExecutionListener;

public class StartListener implements ExecutionListener {
    @Override
    public void notify(DelegateExecution execution) {

        System.out.println();
        System.out.println("=====================监听器开始执行");
        System.out.println("getId "+execution.getId());
        System.out.println("getCurrentActivitiListener "+execution.getCurrentActivitiListener());
        System.out.println("getCurrentActivityId "+execution.getCurrentActivityId());
        System.out.println("getCurrentFlowElement "+execution.getCurrentFlowElement());
        System.out.println("getExecutions "+execution.getExecutions());
        System.out.println("getParent "+execution.getParent());
        System.out.println("getParentId "+execution.getParentId());
        System.out.println("ProcessInstanceBusinessKey "+execution.getProcessInstanceBusinessKey());

        String eventName = execution.getEventName();
        System.out.println(eventName);

        if ("start".equals(eventName)) {
            System.out.println("start=========");
        }else if ("end".equals(eventName)) {
            System.out.println("end=========");
        } else if ("task".equals(eventName)) {
            System.out.println("用户任务执行");
        }


        System.out.println("=====================监听器结束执行");
        System.out.println();

    }
}
