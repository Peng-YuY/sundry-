package com.tl.listener;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;

public class TestPingFenListener implements JavaDelegate {
    @Override
    public void execute(DelegateExecution execution) {

        System.out.println("=====================服务任务开始");
        System.out.println();
        System.out.println("-------------评分逻辑----------");
        System.out.println(execution.getEventName());

        System.out.println(execution.getProcessDefinitionId());
        System.out.println(execution.getProcessInstanceId());
        System.out.println();
        System.out.println("=====================服务任务结束");

    }
}
