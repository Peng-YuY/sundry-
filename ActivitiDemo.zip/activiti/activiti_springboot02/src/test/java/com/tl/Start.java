package com.tl;

import com.tl.utils.SecurityUtil;
import jdk.management.resource.internal.inst.SocketOutputStreamRMHooks;
import org.activiti.api.process.model.ProcessDefinition;
import org.activiti.api.process.model.ProcessInstance;
import org.activiti.api.process.model.builders.ProcessPayloadBuilder;
import org.activiti.api.process.runtime.ProcessRuntime;
import org.activiti.api.runtime.shared.query.Page;
import org.activiti.api.runtime.shared.query.Pageable;
import org.activiti.api.task.model.builders.TaskPayloadBuilder;
import org.activiti.api.task.runtime.TaskRuntime;
import org.activiti.api.task.model.Task;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.impl.transformer.Identity;
import org.activiti.engine.task.IdentityLink;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(SpringRunner.class)
@SpringBootTest
public class Start {

    @Autowired
    private ProcessRuntime processRuntime;
    @Autowired
    private TaskRuntime taskRuntime;
    @Autowired
    private SecurityUtil securityUtil;

    @Autowired
    private TaskService taskService;

    @Autowired
    private RuntimeService runtimeService;



    @Test
    public void findProcess(){
        securityUtil.logInAs("南中心");
        Page<org.activiti.api.process.model.ProcessDefinition> processDefinitionPage =
                processRuntime.processDefinitions(Pageable.of(0, 10));
        System.out.println("可用的流程定义数量：" + processDefinitionPage.getTotalItems());
        for (org.activiti.api.process.model.ProcessDefinition pd : processDefinitionPage.getContent()) {
            System.out.println("流程定义：" + pd);
        }
    }

    @Test
    public void startProcesses(){
        securityUtil.logInAs("南中心");
        ProcessInstance pi = processRuntime.start(ProcessPayloadBuilder.
                start().
                withProcessDefinitionKey("service-95598").
                withProcessInstanceName("启动测试").
                build());

       /* ProcessInstance processInstance = processRuntime.start(ProcessPayloadBuilder
                .start()
                .withProcessDefinitionKey("service-95598")
                .withName(tlWorkflow95598.getTitle())
                .withBusinessKey(id)
                .build());*/


        org.activiti.engine.task.Task task1 = taskService.createTaskQuery().processInstanceId(pi.getId()).singleResult();
        System.out.println("任务id1: "+task1);

        Page<Task> taskPage=taskRuntime.tasks(Pageable.of(0,10));
        if (taskPage.getTotalItems()>0){
            for (Task task:taskPage.getContent()){
                System.out.println("任务id: "+task.getId());
            }
        }

        System.out.println("流程实例ID：" + pi.getId());
        System.out.println(pi.getProcessDefinitionKey());
        System.out.println(pi.getName());
        System.out.println(pi.getStartDate());
        System.out.println(pi.getStatus());

    }
    /*
    * 任务id: 08523044-8013-11eb-b871-002b67e463ad
    任务id: 60f03186-8013-11eb-8e80-002b67e463ad
    任务id: d7c01b65-8012-11eb-a5a3-002b67e463ad
        任务id: 9af73c81-8013-11eb-b6cb-002b67e463ad
    *
    * */

    /**
     **查询任务，并完成自己的任务
     **/
    @Test
    public void testTask() {
        String user="南中心";

        securityUtil.logInAs(user);
        Page<Task> taskPage=taskRuntime.tasks(Pageable.of(0,10));
        if (taskPage.getTotalItems()>0){
            for (Task task:taskPage.getContent()){
                taskRuntime.claim(TaskPayloadBuilder.
                        claim().
                        withTaskId(task.getId()).build());
                System.out.println("任务："+task);
                System.out.println("任务id: "+task.getId());

                //如果是施工班组接单啦,那么配置流程变量。现场确认以及完成工单的人员
                if ("班组接单".equals(user)){
                    HashMap<String, Object> variables = new HashMap<>();
                    variables.put("service","班组接单");
                    Task complete = taskRuntime.complete(TaskPayloadBuilder.
                            complete().
                            withTaskId(task.getId())
                            .withVariables(variables)
                            .build());
                    System.out.println("设置流程变量成功: "+complete.getAssignee());
                    return;
                }
                taskRuntime.complete(TaskPayloadBuilder.
                        complete().
                        withTaskId(task.getId())
                        .build());


                System.out.println("任务完成");
            }
        }
        Page<Task> taskPage2=taskRuntime.tasks(Pageable.of(0,10));
        if (taskPage2.getTotalItems()>0){
            System.out.println("查询当前用户任务");
            System.out.println("任务："+taskPage2.getContent());
        }
    }

    @Test
    public void findTask() {
        securityUtil.logInAs("南中心");
        Page<Task> taskPage = taskRuntime.tasks(Pageable.of(0, 10));
        if (taskPage.getTotalItems() > 0) {
            for (Task task : taskPage.getContent()) {
                System.out.println("taskId: "+task.getId());
                List<IdentityLink> identityLinksForTask = taskService.getIdentityLinksForTask(task.getId());
                identityLinksForTask.forEach(i -> System.out.println("组id: "+i.getGroupId()+" "+"用户id: "+i.getUserId()));

                System.out.println("task.assignee: "+task.getAssignee());
                System.out.println("task.name: "+task.getName());
                System.out.println("task.parentId "+task.getParentTaskId());
                System.out.println(task.getDescription());
                System.out.println(task.getStatus());

                List<org.activiti.engine.task.Task> list = taskService.createTaskQuery().processInstanceId(task.getProcessInstanceId()).taskCandidateGroup("XDistribute").list();
                for (org.activiti.engine.task.Task task1 : list) {
                    System.out.println("task1.getDelegationState(): "+task1.getDelegationState());
                    System.out.println("task1.getAssignee(): "+task1.getAssignee());
                }


                org.activiti.engine.runtime.ProcessInstance processInstance = runtimeService.createProcessInstanceQuery().processInstanceId(task.getProcessInstanceId()).singleResult();


                System.out.println("实例启动用户id "+processInstance.getStartUserId());
                System.out.println("流程定义id "+processInstance.getProcessDefinitionId());
                System.out.println("流程定义key "+processInstance.getProcessDefinitionKey());
                System.out.println("流程定义名称 "+processInstance.getProcessDefinitionName());
                System.out.println("流程实例名称 "+processInstance.getName());
                System.out.println("流程启动时间: "+processInstance.getStartTime());
                System.out.println("流程实例parentId "+processInstance.getParentId());


            }
        }
    }

}
