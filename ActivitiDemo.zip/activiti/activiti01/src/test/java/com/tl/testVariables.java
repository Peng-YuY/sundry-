package com.tl;

import com.tl.pojo.Evection;
import org.activiti.engine.*;
import org.activiti.engine.task.Task;
import org.junit.Test;

import java.util.HashMap;

public class testVariables {
    ProcessEngine defaultProcessEngine = ProcessEngines.getDefaultProcessEngine();


    @Test
    public void testDeployment(){
        RepositoryService repositoryService = defaultProcessEngine.getRepositoryService();
        repositoryService.createDeployment()
                .addClasspathResource("bpmn/evection-global.bpmn")
                .name("出差申请流程-variables")
                .deploy();
    }


    @Test
    public void testStartProcess(){
        RuntimeService runtimeService = defaultProcessEngine.getRuntimeService();
        String key="myProcess_1";
        HashMap<String, Object> map = new HashMap<>();

        //设置流程变量
        Evection evection = new Evection();
        evection.setNum(2d);

        map.put("evection",evection);
        runtimeService.startProcessInstanceByKey(key,map);
    }


    @Test
    public void completTask(){
        TaskService taskService = defaultProcessEngine.getTaskService();
        Task task = taskService.createTaskQuery()
                .processDefinitionKey("myProcess_1")
                .singleResult();

        if (task!=null){
            //根据任务id完成任务
            taskService.complete(task.getId());
        }
    }

}
