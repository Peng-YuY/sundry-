package com.tl;

import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngines;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.runtime.ProcessInstance;
import org.junit.Test;

public class ActivitiBusinessDemo {

    ProcessEngine defaultProcessEngine = ProcessEngines.getDefaultProcessEngine();


    /**
     * 添加业务key到Activit的表
     *
     */
    @Test
    public void addBusinessDemo(){
        //获取runtimeService
        RuntimeService runtimeService = defaultProcessEngine.getRuntimeService();
        //启动流程的过程中 添加businessKey

        //第一个参数流程定义的key   第二个参数需要绑定的businessKey,业务申请流程的id
        ProcessInstance myEvection = runtimeService.startProcessInstanceByKey("myEvection", "1001");

        System.out.println("businessKey: "+myEvection.getBusinessKey());


    }

}
