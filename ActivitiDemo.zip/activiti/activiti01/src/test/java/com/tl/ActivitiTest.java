package com.tl;


import org.activiti.engine.*;
import org.junit.Test;

public class ActivitiTest {


    @Test
    public void testCreateActiviti(){
        //获取activiti提供的工具类,默认会从resources下读取名字为activiti.cfg.xml的文件
        //创建processEngine时,就会创建mysql的表
        ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();
        System.out.println(processEngine);

        //使用自定义的方式,配置文件名可以自定义.bean的id也可以自定义
        ProcessEngineConfiguration configurationFromResource =
                ProcessEngineConfiguration.createProcessEngineConfigurationFromResource("activiti.cfg.xml","processEngineConfiguration");

       /* //获取流程引擎对象
        ProcessEngine processEngine1 = configurationFromResource.buildProcessEngine();
        System.out.println(processEngine1);

        //repositoryService activiti资源管理类
        RepositoryService repositoryService = processEngine.getRepositoryService();

        //runtimeService activiti流程运行管理类
        RuntimeService runtimeService = processEngine.getRuntimeService();

        //historyService activiti任务管理类
        HistoryService historyService = processEngine.getHistoryService();

        //managementService activiti引擎管理类
        ManagementService managementService = processEngine.getManagementService();

        //taskService activiti管理类任务管理类
        TaskService taskService = processEngine.getTaskService();*/

    }

}
