package com.tl;

import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngines;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.runtime.ProcessInstance;
import org.junit.Test;

public class TestStart {

    ProcessEngine defaultProcessEngine = ProcessEngines.getDefaultProcessEngine();


    @Test
    public void start(){
        RepositoryService repositoryService = defaultProcessEngine.getRepositoryService();
        Deployment deploy = repositoryService.createDeployment()
                .addClasspathResource("bpmn/test01.bpmn")
                .name("服务任务测试01")
                .deploy();
        System.out.println("流程部署id= "+deploy.getId());
        System.out.println("流程部署名称: "+deploy.getName());

    }

    @Test
    public void create(){
        ProcessInstance test = defaultProcessEngine.getRuntimeService().startProcessInstanceByKey("test01");

        System.out.println("流程定义id: "+test.getProcessDefinitionId());
        System.out.println("流程实例id: "+test.getId());
        System.out.println("当前活动的id: "+test.getDeploymentId());
        System.out.println(test.getProcessDefinitionKey());
        System.out.println(test.getProcessDefinitionName());
    }

}
