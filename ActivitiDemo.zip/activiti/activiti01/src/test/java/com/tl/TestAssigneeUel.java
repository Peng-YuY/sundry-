package com.tl;

import org.activiti.engine.*;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.task.Task;
import org.junit.Test;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestAssigneeUel {

    @Test
    public void  testDeployment(){
        ProcessEngine defaultProcessEngine = ProcessEngines.getDefaultProcessEngine();
        RepositoryService repositoryService = defaultProcessEngine.getRepositoryService();
        Deployment deploy = repositoryService.createDeployment()
                .name("出差申请-uel")
                .addClasspathResource("bpmn/evection-uel.bpmn")
                .deploy();

        System.out.println("流程部署id= "+deploy.getId());
        System.out.println("流程部署名称: "+deploy.getName());
    }


    @Test
    public void startAssigneeUel(){
        ProcessEngine defaultProcessEngine = ProcessEngines.getDefaultProcessEngine();
        RuntimeService runtimeService = defaultProcessEngine.getRuntimeService();
        Map<String, Object> map = new HashMap<>();
        map.put("assignee0","张三");
        map.put("assignee1","李");
        map.put("assignee2","王");
        map.put("assignee3","赵");
        runtimeService.startProcessInstanceByKey("myEvection1",map);
    }


    @Test
    public void findPersonalTaskList(){
        String processDefinitionKey="myEvection1";
        String assignee="张三";

        ProcessEngine defaultProcessEngine = ProcessEngines.getDefaultProcessEngine();
        TaskService taskService = defaultProcessEngine.getTaskService();
        List<Task> list = taskService.createTaskQuery()
                .processDefinitionKey(processDefinitionKey)
                .includeProcessVariables()
                .taskAssignee(assignee)
                .list();

        for (Task task : list) {
            System.out.println("----------------------->");
            System.out.println("流程实例id: "+task.getProcessInstanceId());
            System.out.println("任务id: "+task.getId());
            System.out.println("任务负责人: "+task.getAssignee());
            System.out.println("任务名称: "+task.getName());
        }
    }

}
