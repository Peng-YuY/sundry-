package com.tl;

import org.activiti.engine.*;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.HistoricActivityInstanceQuery;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.repository.ProcessDefinitionQuery;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.apache.commons.io.IOUtils;
import org.junit.Test;

import java.io.*;
import java.util.List;
import java.util.zip.ZipInputStream;

public class ActivitiDemo {

    ProcessEngine defaultProcessEngine = ProcessEngines.getDefaultProcessEngine();



    /**
     * 流程部署
     */
    @Test
    public void testDeployment() throws IOException {
        /*FileInputStream fileInputStream = new FileInputStream(new File("bpmn/1.txt"));
        byte[] bytes = new byte[1024];
        int leng=0;
        StringBuilder sb = new StringBuilder();
        while (-1!=(leng=fileInputStream.read())){
            sb.append((char) leng);
        }
        System.out.println(sb);*/


        // 1.创建ProcessEngine
        ProcessEngine defaultProcessEngine = ProcessEngines.getDefaultProcessEngine();
        // 2.获取RepositoryService
        RepositoryService repositoryService = defaultProcessEngine.getRepositoryService();
        // 3.使用service进行流程的部署，定义一个流程的名字，把bpmn和png部署到数据库中
        Deployment deploy = repositoryService.createDeployment()
                .name("出差申请流程")
                .addClasspathResource("bpmn/evection.bpmn")
                .addClasspathResource("bpmn/evection.png")
                .deploy();

        // 4.输出部署信息
        System.out.println("流程部署的id= "+deploy.getId());
        System.out.println("流程部署的名字= "+deploy.getName());


        /**
         * ACT_RE_DEPLOYMENT  流程部署表,每部署一次会增加一条记录
         * ACT_RE_PROCDEF     流程定义表
         * ACT_GE_BYTEARRAY   流程资源表
         * */
    }


    /**
     * 使用zip包进行批量的流程部署
     */
    @Test
    public void  deployProcessByZip(){
        //获取流程引擎
        ProcessEngine defaultProcessEngine = ProcessEngines.getDefaultProcessEngine();
        //获取repositoryService
        RepositoryService repositoryService = defaultProcessEngine.getRepositoryService();
        //流程部署
        //读取资源部文件，构造inputStream
        InputStream inputStream=this.getClass().getClassLoader().getResourceAsStream("bpmn/evection.zip");
        //搜用inputSteam构造zip流
        ZipInputStream zipInputStream = new ZipInputStream(inputStream);
        //使用zip流j进行流程的部署
        Deployment deploy = repositoryService.createDeployment()
                .addZipInputStream(zipInputStream)
                .deploy();

        System.out.println("流程部署的id: "+deploy.getId());
        System.out.println("流程部署的名称: "+deploy.getName());
    }



    @Test
    public void createStartProcess(){
        ProcessEngine defaultProcessEngine = ProcessEngines.getDefaultProcessEngine();
        RuntimeService runtimeService = defaultProcessEngine.getRuntimeService();
        ProcessInstance myEvection = runtimeService.startProcessInstanceByKey("myEvection");
        System.out.println("流程定义id: "+myEvection.getProcessDefinitionId());
        System.out.println("流程实例id: "+myEvection.getId());
        System.out.println("当前活动的id: "+myEvection.getDeploymentId());
        System.out.println(myEvection.getProcessDefinitionKey());
        System.out.println(myEvection.getProcessDefinitionName());
    }


    /**
     * 查询个人待执行的任务
     */
    @Test
    public void testFindPersonalTaskList(){
        //1.获取流程引擎
        ProcessEngine defaultProcessEngine = ProcessEngines.getDefaultProcessEngine();
        //2.获取taskService
        TaskService taskService = defaultProcessEngine.getTaskService();
        //3.根据流程key和任务责任人  查询任务
        List<Task> taskList = taskService.createTaskQuery()
                .processDefinitionKey("myEvection")  //流程key
                .taskAssignee("zhangsan")           //要查询的负责人
                .list();
        //4.输出
        for (Task task : taskList) {
            System.out.println("流程实例id: "+task.getProcessDefinitionId());
            System.out.println("任务id: "+task.getId());
            System.out.println("任务负责人: "+task.getAssignee());
            System.out.println("任务名称: "+task.getName());

        }

    }

    /**
     * 完成个人任务
     */
    @Test
    public void completTask(){
        ProcessEngine defaultProcessEngine = ProcessEngines.getDefaultProcessEngine();
        TaskService taskService = defaultProcessEngine.getTaskService();

        //完成任务id为7505的任务
        //taskService.complete("7505");

        //获取jerry - myEvection对应的任务
        /*Task task = taskService.createTaskQuery()
                .processDefinitionKey("myEvection")
                .taskAssignee("jerry")
                .singleResult();*/

        //完成jack的任务
        /*Task task = taskService.createTaskQuery()
                .processDefinitionKey("myEvection")
                .taskAssignee("jack")
                .singleResult();*/

        //完成rose的任务
        Task task = taskService.createTaskQuery()
                .processDefinitionKey("myEvection")
                .taskAssignee("rose")
                .singleResult();

        System.out.println("流程实例id: "+task.getProcessInstanceId());
        System.out.println("任务id: "+task.getId());
        System.out.println("任务负责人: "+task.getAssignee());
        System.out.println("任务名称: "+task.getName());
        taskService.complete(task.getId());

    }


    @Test
    public void queryProcessDefinition(){
        RepositoryService repositoryService = defaultProcessEngine.getRepositoryService();
        ProcessDefinitionQuery processDefinitionQuery = repositoryService.createProcessDefinitionQuery();

        //查询当前所有的流程定义,返回流程定义信息的集合  processDefinitionKey(String -- 流程定义的key)
        List<ProcessDefinition> myEvection = processDefinitionQuery.processDefinitionKey("myEvection")
                //进行排序
                .orderByProcessDefinitionVersion()
                //倒叙,如果要使用正序使用 asc()方法
                .desc()
                //查询所有的
                .list();
    }

    /**
     * 删除流程部署信息
     * 当前的流程如果并没有完成，想要删除的话需要使用特殊方式，原理就是级联删除
     */
    @Test
    public void deleteDeployMent(){
        RepositoryService repositoryService = defaultProcessEngine.getRepositoryService();
       // repositoryService.deleteDeployment("1");
        //true 执行级联删除.   false 或为空 不执行级联删除
        repositoryService.deleteDeployment("1",true);

    }


    /**
     * 流程资源下载
     * 方案1:使用activiti的api 下载资源文件,保存到文件目录
     * 方案2:自己写代码从数据库中下载文件  使用jdbc对blob类型、clob类型读取，保存到文件目录
     * 解决io操作: commons-io.jar
     *
     * 这里使用方案1:RepositoryService
     */
    @Test
    public void getDeployment() throws IOException {
        RepositoryService repositoryService = defaultProcessEngine.getRepositoryService();
        //获取查询对象 ProcessDefinitionQuery 查询流程定义信息
        ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery()
                .processDefinitionKey("myEvection")
                .singleResult();
        //通过流程定义信息，获取流程部署id
        String deploymentId = processDefinition.getDeploymentId();
        //通过repositoryService，传递部署id读取资源信息
            //1. 获取png资源
            //从流程定义表中,获取png图片的目录和名字
        String pngName = processDefinition.getDiagramResourceName();
        //通过部署id和文件的名称来获取图片的资源
        InputStream pngInput = repositoryService.getResourceAsStream(deploymentId, pngName);

        //2. 获取bpmn资源
        String bpmnName = processDefinition.getResourceName();
        InputStream bpmnInput = repositoryService.getResourceAsStream(deploymentId, bpmnName);

        File pngFile = new File("d:/evectionFlow01.png");
        File bpmnFile = new File("d:/evectionFlow01.bpmn");
        //构造outputStream
        FileOutputStream pngFileOutputStream = new FileOutputStream(pngFile);
        FileOutputStream bpmnFileOutputStream = new FileOutputStream(bpmnFile);

        //输入 输出流转换
        IOUtils.copy(pngInput,pngFileOutputStream);
        IOUtils.copy(bpmnInput,bpmnFileOutputStream);

        //流关闭
        pngFileOutputStream.close();
        bpmnFileOutputStream.close();
        pngInput.close();
        bpmnInput.close();
    }


    /**
     * 查看历史信息
     */
    @Test
    public void findHistory(){
        HistoryService historyService = defaultProcessEngine.getHistoryService();
        //获取actInstance表对象
        HistoricActivityInstanceQuery historicActivityInstanceQuery = historyService.createHistoricActivityInstanceQuery();
        historicActivityInstanceQuery.processInstanceId("5001");
        //增加排序操作,根据开始时间排序 asc()
        historicActivityInstanceQuery.orderByHistoricActivityInstanceStartTime().asc();
        List<HistoricActivityInstance> list = historicActivityInstanceQuery.list();

        for (HistoricActivityInstance hi : list) {
            System.out.println(hi.getActivityId());
            System.out.println(hi.getActivityName());
            System.out.println(hi.getProcessDefinitionId());
            System.out.println(hi.getProcessInstanceId());
            System.out.println("<====================>");
        }


    }


}
