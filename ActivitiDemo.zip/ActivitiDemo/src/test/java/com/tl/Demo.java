package com.tl;

import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngines;
import org.junit.Test;

public class Demo {

    ProcessEngine defaultProcessEngine = ProcessEngines.getDefaultProcessEngine();

    @Test
    public void test(){

    }

}
